from fastapi import FastAPI, Request, APIRouter
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from services.chat_service import LangGraphChatbotMemory


app = FastAPI(title="Home Router with Chat Service")

api_router = APIRouter(prefix="/api/home", tags=["Home Operations"])

class ChatRequest(BaseModel):
    message: str

@api_router.post("/chat", response_class=JSONResponse)
async def read_root(request: ChatRequest):
    """Render the home page using Jinja2 template."""
    bot = LangGraphChatbotMemory()
    response = bot.ask(request.message)
    return {"message": response, "status": "success"}