from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from routers.home_router import api_router
from routers.db_router import db_router 

app = FastAPI(title="Sample FastAPI with Templates")

# Mount static files (CSS, JS, images)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

app.include_router(api_router)
app.include_router(db_router)

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
	"""Render home1 page using Jinja2 template."""
	return templates.TemplateResponse("home1.html", {"request": request, "title": "Home 1"})


@app.get("/home1", response_class=HTMLResponse)
async def home1(request: Request):
	"""Home 1 page - Minimal content."""
	return templates.TemplateResponse("home1.html", {"request": request, "title": "Home 1"})


@app.get("/home2", response_class=HTMLResponse)
async def home2(request: Request):
	"""Home 2 page - Features overview."""
	return templates.TemplateResponse("home2.html", {"request": request, "title": "Home 2"})


@app.get("/get-started", response_class=HTMLResponse)
async def get_started(request: Request):
	"""Get started with FastAPI page."""
	return templates.TemplateResponse("get-started.html", {"request": request, "title": "Get Started"})


@app.get("/easy-setup", response_class=HTMLResponse)
async def easy_setup(request: Request):
	"""Easy setup and configuration page."""
	return templates.TemplateResponse("easy-setup.html", {"request": request, "title": "Easy Setup"})


@app.get("/data-ingestion", response_class=HTMLResponse)
async def data_ingestion(request: Request):
	"""Data ingestion page."""
	return templates.TemplateResponse("data-ingestion.html", {"request": request, "title": "Data Ingestion"})


@app.get("/prompts", response_class=HTMLResponse)
async def prompts(request: Request):
	"""Prompts management page."""
	return templates.TemplateResponse("prompts.html", {"request": request, "title": "Prompts"})


@app.get("/evaluations", response_class=HTMLResponse)
async def evaluations(request: Request):
	"""Evaluations page."""
	return templates.TemplateResponse("evaluations.html", {"request": request, "title": "Evaluations"})


@app.get("/crud", response_class=HTMLResponse)
async def crud(request: Request):
	"""CRUD operations page."""
	return templates.TemplateResponse("crud.html", {"request": request, "title": "CRUD"})


if __name__ == "__main__":
	# Run with: python app.py
	import uvicorn

	uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
