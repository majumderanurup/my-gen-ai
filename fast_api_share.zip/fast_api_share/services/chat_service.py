from langgraph.graph.message import add_messages, BaseMessage
import operator
from langchain_openai import ChatOpenAI
from dotenv import dotenv_values
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from datetime import datetime
from langgraph.checkpoint.memory import MemorySaver


class LangGraphChatbotMemory:

    # ------------ State Definition ------------
    class State(TypedDict):
        count: Annotated[int, operator.add]
        timestamps: Annotated[list[str], operator.add]
        messages: Annotated[list[BaseMessage], lambda l, r: LangGraphChatbotMemory.add_messages_with_limit(l, r, 8)]

    @staticmethod
    def add_messages_with_limit(left, right, limit=8):
        merged = add_messages(left, right)
        return merged[-limit:]

    # ------------ Constructor ------------
    def __init__(self, model_name="gpt-4o", env_path=".env", thread_id="1"):
        config = dotenv_values(env_path)
        api_key = config.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY missing from .env")

        # LLM
        self.llm = ChatOpenAI(api_key=api_key, model=model_name)

        # Graph setup
        self.graph_builder = StateGraph(self.State)
        self.graph_builder.add_node("CHATBOT", self.chatbot)
        self.graph_builder.add_edge(START, "CHATBOT")
        self.graph_builder.add_edge("CHATBOT", END)

        # Memory
        self.memory = MemorySaver()
        self.graph = self.graph_builder.compile(checkpointer=self.memory)

        # Unique conversation thread
        self.invoke_config = {"configurable": {"thread_id": thread_id}}

    # ------------ Node Logic ------------
    def chatbot(self, state: State):
        current_time = str(datetime.now())

        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            *state["messages"]
        ]

        resp = self.llm.invoke(messages)

        return {
            "count": 1,
            "timestamps": [current_time],
            "messages": [{"role": "assistant", "content": resp.content}]
        }

    # ------------ PUBLIC METHOD: One Input → One Output ------------
    def ask(self, user_input: str) -> str:
        """
        Send one user message and return the assistant’s reply.
        Memory is automatically applied by the graph + MemorySaver.
        """
        # Only initial state; memory makes it persistent across calls
        initial_state = {
            "count": 0,
            "timestamps": [],
            "messages": [{"role": "user", "content": user_input}]
        }

        new_state = self.graph.invoke(initial_state, self.invoke_config)

        # Return assistant’s final output
        return new_state["messages"][-1].content


# Example usage (not a loop)
if __name__ == "__main__":
    bot = LangGraphChatbotMemory()
    reply = bot.ask("I am Anurup")
    print("Assistant:", reply)
    reply = bot.ask("Who won the world series in 2020?")
    print("Assistant:", reply)
    reply = bot.ask("Where was it played?")
    print("Assistant:", reply)
    reply = bot.ask("What is my name?")
    print("Assistant:", reply)
