import sqlite3
import csv
import os

class DBService:

    def __init__(self, db_name="db/local.db"):
        self.db_name = db_name
        self.conn = sqlite3.connect(self.db_name)
        self.cursor = self.conn.cursor()

    # ----------------------------------------------------
    # Import CSV → Create Table (with PK starting at 1001)
    # ----------------------------------------------------
    def import_csv(self, csv_file, table_name):
        if not os.path.exists(csv_file):
            raise FileNotFoundError(f"{csv_file} not found")

        with open(csv_file, "r", encoding="utf-8") as file:
            reader = csv.reader(file)
            headers = next(reader)

            # Create table with auto-increment PK
            cols = ", ".join([f'"{col}" TEXT' for col in headers])
            create_query = f'''
                CREATE TABLE IF NOT EXISTS "{table_name}" (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    {cols}
                );
            '''
            self.cursor.execute(create_query)
            self.conn.commit()

            # Seed AUTOINCREMENT to start at 1001
            self.cursor.execute("""
                INSERT OR IGNORE INTO sqlite_sequence (name, seq)
                VALUES (?, 1000);
            """, (table_name,))
            self.conn.commit()

            # Insert rows
            placeholders = ", ".join(["?"] * len(headers))
            insert_query = f'''
                INSERT INTO "{table_name}" ({", ".join(headers)})
                VALUES ({placeholders})
            '''

            for row in reader:
                self.cursor.execute(insert_query, row)

            self.conn.commit()
            print(f"Imported CSV into '{table_name}' with autoincrement PK starting at 1001.")

    # ---------------------------
    # Insert (auto PK starts 1001)
    # ---------------------------
    def insert(self, table, data: dict):
        keys = ", ".join(data.keys())
        placeholders = ", ".join("?" for _ in data)

        query = f'INSERT INTO "{table}" ({keys}) VALUES ({placeholders})'
        self.cursor.execute(query, tuple(data.values()))
        self.conn.commit()

        return self.cursor.lastrowid  # return generated ID

    # ---------------------------
    # Update
    # ---------------------------
    def update(self, table, data: dict, where: dict):
        set_clause = ", ".join([f"{k}=?" for k in data.keys()])
        where_clause = " AND ".join([f"{k}=?" for k in where.keys()])

        values = list(data.values()) + list(where.values())

        query = f'UPDATE "{table}" SET {set_clause} WHERE {where_clause}'
        self.cursor.execute(query, values)
        self.conn.commit()

    # ---------------------------
    # Read one record
    # ---------------------------
    def read(self, table, where: dict):
        where_clause = " AND ".join([f"{k}=?" for k in where.keys()])
        values = tuple(where.values())

        query = f'SELECT * FROM "{table}" WHERE {where_clause}'
        self.cursor.execute(query, values)
        return self.cursor.fetchone()

    # ---------------------------
    # Read all
    # ---------------------------
    def read_all(self, table):
        query = f'SELECT * FROM "{table}"'
        self.cursor.execute(query)
        return self.cursor.fetchall()

    # ---------------------------
    # Delete
    # ---------------------------
    def delete(self, table, where: dict):
        where_clause = " AND ".join([f"{k}=?" for k in where.keys()])
        values = tuple(where.values())

        query = f'DELETE FROM "{table}" WHERE {where_clause}'
        self.cursor.execute(query, values)
        self.conn.commit()

    # ---------------------------
    # Close connection
    # ---------------------------
    def close(self):
        self.conn.close()



# db = DBService()

# # Import CSV into a table
# db.import_csv("data/evaluations.csv", "evaluations")


db = DBService()

# Read all rows
rows = db.read_all("evaluations")
print(rows)