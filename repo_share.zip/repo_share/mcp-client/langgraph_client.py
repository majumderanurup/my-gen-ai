from typing import Annotated
from langchain_core.messages import HumanMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI
import asyncio
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition

class State(TypedDict):
    messages: Annotated[list, add_messages]

client = MultiServerMCPClient(
    {
        "math": {
            "transport": "streamable_http",  # HTTP-based remote server
            # Ensure you start your weather server on port 8000
            "url": "http://localhost:8000/mcp",
        }
    }
)

async def main():
    graph_builder = StateGraph(State)

    llm = ChatOpenAI(api_key="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", 
                        model="gpt-4o", 
                        temperature=0.1)
    tools = await client.get_tools()
    llm_with_tools = llm.bind_tools(tools)

    def chatbot(state: State):
        return {"messages": [llm_with_tools.ainvoke(state["messages"])]}

    graph_builder.add_node("chatbot", chatbot)

    tool_node = ToolNode(tools=tools)
    graph_builder.add_node("tools", tool_node)

    graph_builder.add_conditional_edges(
        "chatbot",
        tools_condition,
    )
    # Any time a tool is called, we return to the chatbot to decide the next step
    graph_builder.add_edge("tools", "chatbot")
    graph_builder.add_edge(START, "chatbot")
    graph = graph_builder.compile()
    response = graph.ainvoke({
    "messages": [HumanMessage(content="what's (3 + 5) x 12?")]
    })
    print(response["messages"][-2])


if __name__ == "__main__":
    asyncio.run(main())
