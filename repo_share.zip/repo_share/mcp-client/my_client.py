from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI
import asyncio

client = MultiServerMCPClient(
    {
        "math": {
            "transport": "streamable_http",  # HTTP-based remote server
            # Ensure you start your weather server on port 8000
            "url": "http://localhost:8000/mcp",
        }
    }
)

async def main():
    tools = await client.get_tools()
    # print("Retrieved tools:", tools)
    llm = ChatOpenAI(api_key="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", 
                     model="gpt-4o", 
                     temperature=0.1)
    llm = llm.bind_tools(tools)
    llm_response = llm.invoke("what's (3 + 5)")
    print("LLM response:", llm_response)

    # Check if it actually made a tool call
    if hasattr(llm_response, "tool_calls") and llm_response.tool_calls:
        for call in llm_response.tool_calls:
            print(f"\nTool Called: {call['name']}")
            print(f"Arguments: {call['args']}")

if __name__ == "__main__":
    asyncio.run(main())


# agent = create_agent(
#     "anthropic:claude-3-7-sonnet-latest",
#     tools
# )
# math_response = await agent.ainvoke(
#     {"messages": [{"role": "user", "content": "what's (3 + 5) x 12?"}]}
# )
# weather_response = await agent.ainvoke(
#     {"messages": [{"role": "user", "content": "what is the weather in nyc?"}]}
# )