from langchain_openai import ChatOpenAI
from dotenv import dotenv_values
import re
from typing import Tuple, Dict

from pydantic import BaseModel, Field
import threading
import random

from services.db_service import DBService

class EvaluationFormatter(BaseModel):
    """Always use this tool to structure your response to the user."""
    relevance: bool = Field(description="Is the response relevant to the prompt?")
    clarity: bool = Field(description="Is the response clear and easy to understand?")
    completeness: bool = Field(description="Does the response fully address the prompt?")
    groundedness: bool = Field(description="Is the response based on factual information provided in context?")
    hallucination: bool = Field(description="Does the response avoid making up information?")
    reason: str = Field(description="Provide a brief reason for your evaluation regarding each criteria.")

class SensitiveFormatter(BaseModel):
    """Always use this tool to structure your response to the user."""
    sensitive: bool = Field(description="If the input text contains sensitive or inappropriate content, set this to True. Otherwise, set it to False.")
    reason: str = Field(description="Provide a brief reason for your determination regarding the sensitivity of the content.")

class InvokeLLM:

    def __init__(self, model_name: str, 
                 pii_filteration: bool = True, 
                 input_content_filter: bool = True,
                 output_content_filter: bool = True,
                 evaluation: bool = True,
                 evaluation_frequency: int = 0.9):
        
        self.model_name = model_name
        self.pii_filteration = pii_filteration
        self.input_content_filter = input_content_filter
        self.output_content_filter = output_content_filter
        self.evaluation = evaluation
        self.evaluation_frequency = evaluation_frequency

    def content_filter(self, text: str) -> str:
        prompt = f"""
        You are expert in filtering sensitive information from text.
        Given the text, Identify if there is any content that is sensitive or not.
        Sensitive information includes:
        1. Self Harm
        2. Hate Speech
        3. Violence
        4. Adult Content
        5. Illegal Activities
        If any of the above sensitive information is found, respond with True or False.
        Below are not considered sensitive:
        1. Personal Identifiable Information (PII) like Email IDs, Phone Numbers, SSNs etc.
        Here is the text to analyze:
        {text}
        Also provide your response in the structured format.
        """
        llm = ChatOpenAI(model_name=self.model_name, 
                         openai_api_key=dotenv_values(".env")["OPENAI_API_KEY"],
                         temperature=0.1)
        
        llm_with_structure = llm.with_structured_output(SensitiveFormatter)
        response = llm_with_structure.invoke(prompt)
        return response

    def pii_filter(self, text: str) -> Tuple[str, Dict[str, str]]:
        """
        Replaces Email IDs, Phone Numbers, and SSNs with placeholders.
        Returns filtered_text and mapping for restoration.
        """
        print("Applying PII filter...")
        patterns = {
            "EMAIL": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
            "PHONE": r"(?<!\d)((?:\+?1[-.\s]?)?(?:\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4})(?!\d)",
            "SSN":   r"\b\d{3}-\d{2}-\d{4}\b"
        }

        mapping = {}
        counter = {"EMAIL": 0, "PHONE": 0, "SSN": 0}

        def replace(match, pii_type):
            counter[pii_type] += 1
            key = f"[{pii_type}_{counter[pii_type]}]"
            mapping[key] = match.group(0)
            return key

        # Apply patterns
        for pii_type, pattern in patterns.items():
            text = re.sub(pattern, lambda m: replace(m, pii_type), text)

        return text, mapping

    def invoke_llm(self, prompt: str) -> str:
        # Placeholder for LLM invocation logic
        config = dotenv_values(".env")
        if self.pii_filteration:
            filtered_prompt, pii_mapping = self.pii_filter(prompt)
        else:
            filtered_prompt = prompt

        if self.input_content_filter:
            is_sensitive = self.content_filter(filtered_prompt).sensitive
            if is_sensitive == True:
                return "Input content is sensitive or inappropriate. Cannot proceed."
            
        llm = ChatOpenAI(model_name=self.model_name, 
                         openai_api_key=config["OPENAI_API_KEY"],
                         temperature=0.1)
        response = llm.invoke(filtered_prompt).content
        
        if self.pii_filteration:
            response = self.pii_restore(response, pii_mapping)
        
        if self.output_content_filter:
            is_sensitive = self.content_filter(response).sensitive
            if is_sensitive == True:
                return "Output content is sensitive or inappropriate. Cannot provide response."

        if self.evaluation:
            if random.random() < self.evaluation_frequency:
                print("Starting evaluation thread...")
                eval_thread = threading.Thread(
                    target=self.evaluate_response,
                    args=(prompt, response),
                    kwargs={"context": ""}
                )
                eval_thread.daemon = False   # Optional: thread will not block program exit
                eval_thread.start()
        return response
    
    def pii_restore(self, text: str, mapping: Dict[str, str]) -> str:
        """
        Restores placeholders in text back to original PII values.
        """
        print("Restoring PII...")
        for placeholder, original in mapping.items():
            text = text.replace(placeholder, original)
        return text
    
    def evaluate_response(self, prompt: str, response: str, context: str) -> bool:
        print("Evaluating response...")
        eval_prompt = f"""
        You are expert in evaluating LLM responses.
        Below are the criteria for evaluation:
        1. Relevance: Is the response relevant to the prompt?
        2. Clarity: Is the response clear and easy to understand?
        3. Completeness: Does the response fully address the prompt?
        4. Groundedness: Is the response based on factual information provided in context? (If context is provided, Otherwise, assume it is grounded)
        5. Hallucination: Does the response avoid making up information?

        Based on the above criteria, evaluate the and respond with True if it meets each criteria. You can respond either True or False for each criteria.
        Also provide reason for your evaluation for all the criteria in brief. Keep this very short. Justify only if any criteria is False.
        Here is the prompt:
        {prompt}
        Here is the response:
        {response}
        Here is the context:
        {context}
        """
        llm = ChatOpenAI(model_name=self.model_name, 
                         openai_api_key=dotenv_values(".env")["OPENAI_API_KEY"],
                         temperature=0.1)
        
        llm_with_structure = llm.with_structured_output(EvaluationFormatter)
        eval_response = llm_with_structure.invoke(eval_prompt)
        db = DBService()
        db.insert("evaluations", {"Question_Answer": f"{prompt} | {response}",
                          "Relevance": eval_response.relevance,
                          "Clarity": eval_response.clarity,
                          "Completeness": eval_response.completeness,
                          "Groundedness": eval_response.groundedness,
                          "Hallucination": eval_response.hallucination,
                          "Comments": eval_response.reason})
        print("Inserted evaluation into database.")
    
if __name__ == "__main__":
    invoke_llm = InvokeLLM(model_name="gpt-4o", 
                           pii_filteration=True,
                           input_content_filter=True,
                           output_content_filter=True)

    prompt = f"""
    What is the capital of France?
    """

    result = invoke_llm.invoke_llm(prompt)
    print(result)