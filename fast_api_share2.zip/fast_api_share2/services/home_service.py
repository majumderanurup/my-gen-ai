from langchain_openai import ChatOpenAI
from dotenv import dotenv_values
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from datetime import datetime
from langgraph.checkpoint.memory import MemorySaver


class LangGraphCountryBot:

    # ------------ State Definition ------------
    class State(TypedDict):
        country: str
        currency: str
        capital: str

    # ------------ Constructor ------------
    def __init__(self, model_name="gpt-4o", env_path=".env", thread_id="1"):
        config = dotenv_values(env_path)
        api_key = config.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY missing from .env")

        self.llm = ChatOpenAI(api_key=api_key, model=model_name)

        # Build graph
        self.graph_builder = StateGraph(self.State)
        self.graph_builder.add_node("LOOKUP", self.lookup)
        self.graph_builder.add_edge(START, "LOOKUP")
        self.graph_builder.add_edge("LOOKUP", END)

        # Memory enabled
        self.memory = MemorySaver()
        self.graph = self.graph_builder.compile(checkpointer=self.memory)

        # Unique conversation/thread
        self.invoke_config = {"configurable": {"thread_id": thread_id}}

    # ------------ Node Logic ------------
    def lookup(self, state: State):
        """
        LLM receives a system prompt instructing it to return the
        currency & capital of the given country.
        """

        system_prompt = (
            "You are a geography assistant. "
            "Given a country name, return ONLY a JSON object with: "
            "country, currency, and capital. Respond in English. "
            "Example:\n"
            '{ "country": "Japan", "currency": "Yen", "capital": "Tokyo" }'
        )

        user_prompt = f"Country: {state['country']}"

        response = self.llm.invoke([
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ])

        # Parse model output (expecting JSON)
        import json
        data = json.loads(response.content)

        return {
            "country": data.get("country", state["country"]),
            "currency": data.get("currency", ""),
            "capital": data.get("capital", "")
        }

    # ------------ Public API: one input → one output ------------
    def ask(self, country: str) -> dict:
        """
        Takes a country name and returns a dictionary:
        {
            "country": ...,
            "currency": ...,
            "capital": ...
        }
        MemorySaver ensures continuity if needed.
        """
        initial_state = {
            "country": country,
            "currency": "",
            "capital": ""
        }

        new_state = self.graph.invoke(initial_state, self.invoke_config)
        return new_state
