from fastapi import UploadFile, File, HTTPException, APIRouter
from pydantic import BaseModel
from typing import Dict, Any, Optional
import shutil
from services.db_service import DBService  # <-- your class file


db_router = APIRouter(prefix="/api/db", tags=["DB Operations"])

db = DBService()  # Single instance


# ----------------------------
# Pydantic Models
# ----------------------------
class InsertRequest(BaseModel):
    table: str
    data: Dict[str, Any]


class UpdateRequest(BaseModel):
    table: str
    data: Dict[str, Any]
    where: Dict[str, Any]


class ReadRequest(BaseModel):
    table: str
    where: Dict[str, Any]


class DeleteRequest(BaseModel):
    table: str
    where: Dict[str, Any]


# ----------------------------
# CSV Upload → Import
# ----------------------------
@db_router.post("/import_csv")
async def import_csv(table: str, file: UploadFile = File(...)):
    try:
        temp_path = f"temp_{file.filename}"

        with open(temp_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        db.import_csv(temp_path, table)
        return {"status": "success", "message": f"Imported CSV into {table}"}

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ----------------------------
# INSERT
# ----------------------------
@db_router.post("/insert")
async def insert_row(req: InsertRequest):
    try:
        row_id = db.insert(req.table, req.data)
        return {"status": "success", "id": row_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ----------------------------
# UPDATE
# ----------------------------
@db_router.put("/update")
async def update_row(req: UpdateRequest):
    try:
        db.update(req.table, req.data, req.where)
        return {"status": "success", "updated": True}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ----------------------------
# READ ONE
# ----------------------------
@db_router.post("/read")
async def read_row(req: ReadRequest):
    try:
        record = db.read(req.table, req.where)
        return {"status": "success", "record": record}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ----------------------------
# READ ALL
# ----------------------------
@db_router.get("/read_all/{table}")
async def read_all(table: str):
    try:
        rows = db.read_all(table)
        return {"status": "success", "rows": rows}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ----------------------------
# DELETE
# ----------------------------
@db_router.delete("/delete")
async def delete_row(req: DeleteRequest):
    try:
        db.delete(req.table, req.where)
        return {"status": "success", "deleted": True}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
