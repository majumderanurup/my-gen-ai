async function fetchWelcome() {
	alert("Fetching welcome message...");
	try {
		const response = await fetch("/api/welcome");
		if (!response.ok) {
			throw new Error(`HTTP error! status: ${response.status}`);
		}
		const data = await response.json();
		// alert(data.message);
		document.getElementById("welcome-message").innerText = data.message;
		return data;
	} catch (error) {
		console.error("Error fetching welcome:", error);
	}
}
