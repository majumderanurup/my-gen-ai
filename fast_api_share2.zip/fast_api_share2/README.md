# Sample FastAPI project with HTML templates

This is a minimal example showing how to serve HTML templates with FastAPI and Jinja2.

Quick start

1. Create a virtual environment and install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r fast_api_project/requirements.txt
```

2. Run the app:

```bash
python app.py
# or with uvicorn directly:
uvicorn app:app --reload
```

Open http://127.0.0.1:8000 in your browser.
